#include "Board.h"
#include <iostream>
#include "application.h"


using namespace std;

int main(){

    Application app;
    app.interaction();

    return 0;
}
