//
// Created by Cian on 04/11/2019.
//

#include <iostream>
#include "Board.h"


using namespace std;

Piece::Piece() {
    type = " ";
}

Piece::~Piece() {
}

void Piece::Draw() {
    if (colour == Black) {
        cout << "b";
    }
    else {
        cout << "w";
    }
    cout << type;
}

void Piece::SetPosition(Position pos) {
    this->pos = pos;
}

Colour Piece::GetColour() {
    return colour;
}
King::King(Colour color, Position pos) {
    this->type = "K";
    this->colour = color;
    this->pos = pos;
}

King::~King() {

}

bool King::ValidateMove(Position moveToPos) {

    return false;
}

Bishop::Bishop(Colour color, Position pos) {
    this->type = "B";
    this->colour = color;
    this->pos = pos;
}

Bishop::~Bishop() {

}

bool Bishop::ValidateMove(Position moveToPos) {

    return false;
}

Knight::Knight(Colour colour, Position pos) {
    this->type = "N";
    this->colour = colour;
    this->pos = pos;
}


Knight::~Knight() {

}

bool Knight::ValidateMove(Position moveToPos) {

    return false;
}

extern Board board;

Pawn::Pawn(Colour colour, Position pos) {
    this->type = "P";
    this->colour = colour;
    this->pos = pos;
    this->doubleJumpAvailable = true;
}


Pawn::~Pawn() {

}


bool Pawn::ValidateMove(Position moveToPos) {


    bool validMove = false;
    int allowableMove1 = 1;
    int allowableMove2 = 2;


    if (colour == Black) {
        allowableMove1 = -1;
        allowableMove2 = -2;
    }


    if (moveToPos.ypos == pos.ypos + allowableMove1 && moveToPos.xpos == pos.xpos && board.GetPiece(moveToPos) == NULL) {
        validMove = true;


        doubleJumpAvailable = false;

    }

    else if (doubleJumpAvailable == true && moveToPos.ypos == (pos.ypos + allowableMove2) && moveToPos.xpos == pos.xpos
             && board.GetPiece(moveToPos) == NULL)   {

        validMove = true;
    }

    else if (moveToPos.ypos == pos.ypos + allowableMove1 && (moveToPos.xpos == pos.xpos - 1 || moveToPos.xpos == pos.xpos + 1) ) {


        if (board.GetPiece(moveToPos) != NULL && (board.GetPiece(moveToPos)->GetColour() != this->colour) )  {
            validMove = true;
        }
    }

    return validMove;
}



Queen::Queen(Colour colour, Position pos) {
    this->type = "Q";
    this->colour = colour;
    this->pos = pos;
}


Queen::~Queen() {

}


bool Queen::ValidateMove(Position moveToPos) {

    return false;
}

Rook::Rook(Colour colour, Position pos) {
    this->type = "R";
    this->colour = colour;
    this->pos = pos;
}


Rook::~Rook() {

}


bool Rook::ValidateMove(Position moveToPos) {

    return false;
}